DROP TABLE IF EXISTS movieuser;

CREATE TABLE movieuser AS SELECT * FROM CSVREAD('classpath:movieuser.csv');

