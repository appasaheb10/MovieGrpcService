package com.grpcflix.user.entity;


import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.ToString;

@Data
@Entity
@ToString
//@Table(name = "\"users\"")
public class MovieUser {

    @Id
    private String login;
    private String name;
    private String genre;
}
